# Google Bookmarks API

A Pen created on CodePen.io. Original URL: [https://codepen.io/talilo-tarlison/pen/zYJyzdd](https://codepen.io/talilo-tarlison/pen/zYJyzdd).

